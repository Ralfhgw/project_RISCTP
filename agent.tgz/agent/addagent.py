from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent

# to use this agent, set the following environment variable:
# export OPENAI_API_KEY='your-key-here'

@tool
def add(a:str, b:str) -> str:
    """
    Adds two integer numbers provided as strings and returns the sum as a string.
    """
    try:
        result = str(int(a) + int(b))
        print('add(' + a + ',' + b + ') = ' + result)
        return result
    except ValueError:
        return "Error: Please provide valid integer strings."

llm = ChatOpenAI(model='gpt-5.2', temperature=0)
tools = [add]
agent = create_agent(llm, tools)

behavior = 'perform calculations only using external tools'
prompt = input('User: ').strip()
result = agent.invoke({"messages": [ SystemMessage(behavior), HumanMessage(prompt) ]})
output = result["messages"][-1].content
print('Agent: ' + output)
