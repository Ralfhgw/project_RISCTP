import sys
import argparse
import os
import requests

from typing import TypedDict, Annotated, Sequence

from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_anthropic import ChatAnthropic
from langchain.agents import create_agent
from langgraph.checkpoint.memory import MemorySaver

import prover

# --- ENVIRONMENT VARIABLES SETUP ---
# To use these LLMs, ensure the following keys are in your environment:
# OpenAI:  export OPENAI_API_KEY='your-key-here'
# Google:  export GOOGLE_API_KEY='your-key-here'
# Claude:  export ANTHROPIC_API_KEY='your-key-here'

# 1. Define the Local Tools

@tool
def download(url: str) -> str:
    """Download resource from the denoted URL and return its content."""
    print("download", url)
    try:
        with requests.get(url) as r:
            return r.text
    except requests.exceptions.RequestException as e:
        return f"An error occurred: {e}"

@tool
def prove(fol_text: str, interactive: bool=False) -> tuple[bool,str]:
    """
    This function applies a prover to a proof problem, either interactively or
    automatically (depending on the value of the second parameter). The first
    parameter is the text of the proof problem in the FOL-PRE syntax
    described at https://www.risc.jku.at/people/schreine/FOL-PRE.txt.
    In the automatic mode, the function returns 'True' if and if the the proof 
    could be completed successfully, together with the output produced by the 
    prover. In the interactive mode, the function always returns False and 
    the empty string (the function blocks until the session has terminated).
    """
    print("prove", "interactive" if interactive else "automatic")
    return prover.prove(fol_text, interactive)

SYSTEM_PROMPT=\
'''
You are a helpful assistant that answers logical questions in the following way
(inform the user before every step what you are going to do):
0. You download the description of the FOL-PRE syntax from
   https://www.risc.jku.at/people/schreine/FOL-PRE.txt and read it carefully.
1. You translate the question into a proof problem in the FOL-PRE syntax
   (make sure it is really in this syntax, do not just guess).
2. You ask the user whether this translation is correct.
3. If the translation is not correct, you follow the suggestions of the user
   to come up with a correct translation; then go back to step 2.
4. Once the translation is correct, you call an automatic prover with the proof 
   problem and present its result (state whether the proof attempt was successful 
   and show the full output produced by the prover).
5. Finally you also offer to to call an interactive prover on the problem
   for investigating the successful proof or the unsuccessful proof attempt.
   Call the interactive prover with the same translation that you used
   for the automatic prover.
Do not try to answer a logical question in any other way. 
'''

class MultiModelAgent:
    def __init__(self, model_type: str):
        self.tools = [download, prove]
        self.memory = MemorySaver()
        self.config = {"configurable": {"thread_id": "default_user"}}
        self.counter = 0
        
        # 2. Initialize the Remote LLM based on user selection
        if model_type == "gpt":
            # GPT-5.2 is the flagship 2026 model for reasoning tasks
            self.llm = ChatOpenAI(model="gpt-5.2", temperature=0)
        elif model_type == "gemini":
            # Gemini 2.5 Pro released in mid-2025
            # self.llm = ChatGoogleGenerativeAI(model="gemini-2.5-pro", temperature=0)
            self.llm = ChatGoogleGenerativeAI(model="gemini-2.5-pro", temperature=0)
        elif model_type == "claude":
            # Claude 4.6 Sonnet released Feb 2026
            self.llm = ChatAnthropic(model="claude-sonnet-4-6", temperature=0)
        else:
            raise ValueError("Unsupported model type.")

        # 3. Create the ReAct Agent using LangGraph
        self.agent_executor = create_agent(
            self.llm, 
            self.tools, 
            checkpointer=self.memory
        )

    def agent(self, query: str) -> str:
        """Processes a query and maintains history."""
        self.counter = self.counter+1
        if self.counter == 1:
            messages = [SystemMessage(content=SYSTEM_PROMPT),HumanMessage(content=query)]
        else:
            messages = [HumanMessage(content=query)]
        input_message = {"messages": messages}
        response = self.agent_executor.invoke(input_message, config=self.config)
        # The last message in the sequence is the agent's final response
        return response["messages"][-1].text

    def reset(self):
        """Clears the history by generating a new thread ID."""
        self.counter = 0
        import uuid
        self.config["configurable"]["thread_id"] = str(uuid.uuid4())
        print("(Conversation history has been reset.)")

def main():
    parser = argparse.ArgumentParser(description="LangChain 2026 ReAct Agent")
    parser.add_argument("-model", choices=["gpt", "gemini", "claude"], default="gpt",
                        help="Select the LLM (default: gpt-5.2)")
    args = parser.parse_args()

    app = MultiModelAgent(args.model)
    print(f"--- Agent Active (Model: {args.model}) ---")
    print("Enter your query. Enter an empty line to exit. Type 'reset' to clear history.")

    while True:
        try:
            user_input = sys.stdin.readline().strip()
            
            if not user_input:
                break
            
            if user_input.lower() == "reset":
                app.reset()
                continue

            answer = app.agent(user_input)
            print(f"Assistant: {answer}")
            
        except EOFError:
            break

if __name__ == "__main__":
    main()