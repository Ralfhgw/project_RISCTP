#!/bin/sh
pip install flask flask_cors
pip install langchain langchain-openai langchain-google-genai langchain-anthropic
