from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

from agent import MultiModelAgent
agent = MultiModelAgent('gpt')

@app.route('/agent', methods=['POST'])
def agent_service():
    # Retrieve the JSON data from the request
    data = request.get_json()
        
    # Check if 'input_string' exists in the sent JSON
    if not data or 'message' not in data:
        return jsonify({"error": "Please provide a 'message' key in your JSON body"}), 400

    # extract the message
    message = data['message']

    # compute the result
    result = agent.agent(message)
    
    # Return the string back as a JSON response
    return jsonify({"result": result})

@app.route('/reset', methods=['POST'])
def reset_service():
    agent.reset()
    return ''

if __name__ == '__main__':
    # Run the server on localhost:5000
    app.run(debug=True, port=5000)